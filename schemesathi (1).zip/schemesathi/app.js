const $ = s => document.querySelector(s);
const S = { lang: localStorage.getItem('lang') || 'hi', view: 'home', step: 0, ans: {}, checked: {} };
const t = k => T[S.lang][k];
const pick = (obj) => obj[S.lang];
const optOf = (key, v) => Q.find(q => q.key === key).options.find(x => x.v === v);

/* ---------- helpers ---------- */
let toastTimer;
function say(msg) {
  const el = $('#toast'); el.textContent = msg; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 4000);
}
function view(name) {
  S.view = name;
  ['home', 'quiz', 'results'].forEach(v => ($('#' + v).hidden = v !== name));
  window.scrollTo(0, 0);
}
const chips = () => Q.filter(q => S.ans[q.key] != null).map(q => {
  const op = optOf(q.key, S.ans[q.key]);
  return `<span class="chip"><span>${op.icon}</span>${pick(op)}</span>`;
}).join('');

/* ---------- voice input (Web Speech API) ---------- */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
function listen(btn, lang = S.lang === 'hi' ? 'hi-IN' : 'en-IN') {
  if (!SR) return say(t('noSR'));
  const r = new SR(); r.lang = lang; r.interimResults = true;
  let text = '';
  r.onstart = () => { btn.classList.add('on'); say(t('listening')); };
  r.onresult = e => { text = [...e.results].map(x => x[0].transcript).join(' '); say('“' + text + '”'); };
  r.onerror = e => {
    if (e.error === 'language-not-supported' && lang !== 'en-IN') return listen(btn, 'en-IN'); // fallback to English
    if (e.error !== 'aborted') say(t('micErr'));
  };
  r.onend = () => { btn.classList.remove('on'); if (text) heard(text); };
  r.start();
}
function heard(text) {
  const found = parse(text);
  if (!Object.keys(found).length) return say(t('micErr'));
  Object.assign(S.ans, found);
  S.view === 'quiz' ? renderQuiz() : renderHeard();
}

/* ---------- home ---------- */
function renderHeard() {
  const box = $('#heard'); box.hidden = !chips();
  if (box.hidden) return;
  const left = Q.some(q => S.ans[q.key] == null);
  box.innerHTML = `<p class="strong">${t('heard')}</p><div class="chips">${chips()}</div>
    <button class="btn" id="go" style="margin-top:14px">${t('showSchemes')}</button>
    ${left ? `<button class="btn ghost" id="more" style="margin-top:10px">${t('continueQ')}</button>` : ''}`;
  $('#go').onclick = showResults;
  if (left) $('#more').onclick = () => { S.step = Q.findIndex(q => S.ans[q.key] == null); renderQuiz(); view('quiz'); };
}

/* ---------- quiz ---------- */
function renderQuiz() {
  const q = Q[S.step];
  $('#bar').style.width = (S.step + 1) * 20 + '%';
  $('#qStep').textContent = `${t('step')} ${S.step + 1}/5`;
  $('#qTitle').textContent = pick(q.title);
  $('#cards').innerHTML = q.options.map((op, i) =>
    `<button class="card${S.ans[q.key] === op.v ? ' sel' : ''}" data-i="${i}"><span>${op.icon}</span>${pick(op)}</button>`).join('');
  $('#prev').textContent = t('back'); $('#skip').textContent = t('skip');
}
function next() {
  if (S.step < 4) { S.step++; renderQuiz(); speak(pick(Q[S.step].title)); } else showResults();
}

/* ---------- spoken explainer (SpeechSynthesis) ---------- */
function speak(text) {
  if (!('speechSynthesis' in window)) return say(t('noTTS'));
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = S.lang === 'hi' ? 'hi-IN' : 'en-IN'; u.rate = 0.9;
  const v = speechSynthesis.getVoices().find(v => v.lang.replace('_', '-').toLowerCase().startsWith(u.lang.slice(0, 2)));
  if (v) u.voice = v; else if (S.lang === 'hi') say(t('noVoice')); // text cards remain as fallback
  speechSynthesis.speak(u);
}
const stepsOf = sc => [t('s1'), pick(sc.how), t('s3')];
const docNames = ids => ids.map(d => pick(DOCS[d]));

/* ---------- results ---------- */
let matched = [];
function showResults() {
  matched = SCHEMES.filter(sc => match(sc.rules, S.ans));
  $('#profile').innerHTML = `<p class="strong">${t('profile')}</p><div class="chips">${chips()}</div>`;
  $('#count').textContent = matched.length ? t('found')(matched.length) : t('none');
  $('#list').innerHTML = matched.map(sc => `
    <article class="scheme">
      <h3>${pick(sc.name)}</h3>
      <p class="benefit">${pick(sc.benefit)}</p>
      <p class="strong">${t('docs')}</p>
      <div class="chips">${sc.docs.map(d => `<span class="chip doc"><span>${DOCS[d].icon}</span>${pick(DOCS[d])}</span>`).join('')}</div>
      <p class="strong" style="margin-top:12px">${t('steps')}</p>
      <ol>${stepsOf(sc).map(x => `<li>${x}</li>`).join('')}</ol>
      <button class="btn listen" data-id="${sc.id}">${t('listen')}</button>
    </article>`).join('');
  renderChecklist();
  $('#note').textContent = t('note');
  $('#restart').textContent = t('restart');
  view('results');
}
function renderChecklist() {
  const ids = [...new Set(matched.flatMap(sc => sc.docs))];
  $('#checklist').hidden = !ids.length;
  $('#checklist').innerHTML = `<h2>${t('checklist')}</h2>` +
    ids.map(d => `<label><input type="checkbox" data-d="${d}"${S.checked[d] ? ' checked' : ''}>
      <span>${DOCS[d].icon} ${pick(DOCS[d])}</span></label>`).join('') +
    `<div class="row actions" style="margin-top:12px">
       <button class="btn ghost" id="print">${t('print')}</button>
       <button class="btn ghost" id="dl">${t('download')}</button>
       <button class="btn ghost" id="wa">${t('whatsapp')}</button>
     </div>`;
}
function summary() {
  const ids = [...new Set(matched.flatMap(sc => sc.docs))];
  return `SchemeSathi\n\n` + matched.map(sc => `• ${pick(sc.name)} — ${pick(sc.benefit)}`).join('\n') +
    `\n\n${t('checklist')}:\n` + docNames(ids).map(n => `☐ ${n}`).join('\n');
}

/* ---------- language ---------- */
function applyLang() {
  document.documentElement.lang = S.lang;
  $('#langBtn').textContent = S.lang === 'hi' ? 'EN' : 'हिं';
  $('#tagline').textContent = t('tagline'); $('#micLabel').textContent = t('mic'); $('#micHint').textContent = t('micHint');
  $('#typed').placeholder = t('typePh'); $('#startQ').textContent = t('startQ');
  if (SR === undefined) say(t('noSR'));
  renderHeard();
  if (S.view === 'quiz') renderQuiz();
  if (S.view === 'results') showResults();
}

/* ---------- events ---------- */
$('#langBtn').onclick = () => { S.lang = S.lang === 'hi' ? 'en' : 'hi'; localStorage.setItem('lang', S.lang); speechSynthesis?.cancel(); applyLang(); };
$('#mic').onclick = e => listen(e.currentTarget);
$('#mic2').onclick = e => listen(e.currentTarget);
$('#typeForm').onsubmit = e => { e.preventDefault(); heard($('#typed').value); };
$('#startQ').onclick = () => { S.step = 0; renderQuiz(); view('quiz'); speak(pick(Q[0].title)); };
$('#qSpeak').onclick = () => speak(pick(Q[S.step].title));
$('#cards').onclick = e => {
  const c = e.target.closest('.card'); if (!c) return;
  const q = Q[S.step]; S.ans[q.key] = q.options[+c.dataset.i].v;
  renderQuiz(); setTimeout(next, 250);
};
$('#prev').onclick = () => (S.step ? (S.step--, renderQuiz()) : view('home'));
$('#skip').onclick = next;
$('#restart').onclick = () => { S.ans = {}; S.checked = {}; speechSynthesis?.cancel(); $('#typed').value = ''; renderHeard(); view('home'); };
$('#list').onclick = e => {
  const b = e.target.closest('.listen'); if (!b) return;
  if (speechSynthesis.speaking) { speechSynthesis.cancel(); return; }
  const sc = SCHEMES.find(x => x.id === b.dataset.id);
  speak([pick(sc.name), pick(sc.benefit), `${t('docsAre')}: ${docNames(sc.docs).join(', ')}`, ...stepsOf(sc)].join('. '));
};
$('#checklist').onclick = e => {
  const id = e.target.id;
  if (id === 'print') window.print();
  if (id === 'dl') {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([summary()], { type: 'text/plain;charset=utf-8' }));
    a.download = 'schemesathi-checklist.txt'; a.click();
  }
  if (id === 'wa') window.open('https://wa.me/?text=' + encodeURIComponent(summary()), '_blank');
};
$('#checklist').onchange = e => { S.checked[e.target.dataset.d] = e.target.checked; };

applyLang();
