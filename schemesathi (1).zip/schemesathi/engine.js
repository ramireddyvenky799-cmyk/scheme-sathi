// Pure logic (no DOM): spoken-query parser and rule-based eligibility engine.

const NUM = { ek: 1, 'एक': 1, do: 2, 'दो': 2, teen: 3, 'तीन': 3, char: 4, chaar: 4, 'चार': 4, panch: 5, paanch: 5, 'पांच': 5, 'पाँच': 5,
  chhe: 6, 'छह': 6, saat: 7, 'सात': 7, aath: 8, 'आठ': 8, nau: 9, 'नौ': 9, das: 10, 'दस': 10, dedh: 1.5, 'डेढ़': 1.5, dhai: 2.5, 'ढाई': 2.5 };

const KEYS = {
  occupation: [
    ['farmer', ['kisan', 'किसान', 'farmer', 'kheti', 'खेती', 'farming']],
    ['labourer', ['majdoor', 'mazdoor', 'मजदूर', 'मज़दूर', 'labour', 'labor', 'karigar', 'कारीगर', 'artisan', 'mistri']],
    ['entrepreneur', ['business', 'vyapar', 'व्यापार', 'dukan', 'दुकान', 'udyami', 'उद्यमी', 'entrepreneur', 'shop']],
    ['student', ['student', 'chhatra', 'छात्र', 'vidyarthi', 'विद्यार्थी']],
    ['homemaker', ['homemaker', 'housewife', 'grihini', 'गृहिणी']],
  ],
};

function parse(raw) {
  const x = raw.toLowerCase(), has = w => w.some(k => x.includes(k)), out = {};

  if (has(['female', 'woman', 'mahila', 'महिला', 'aurat', 'औरत', 'ladki', 'लड़की', 'beti', 'बेटी'])) out.gender = 'female';
  else if (has(['male', 'purush', 'पुरुष', 'aadmi', 'आदमी', 'ladka', 'लड़का'])) out.gender = 'male';

  for (const [v, words] of KEYS.occupation) if (has(words)) { out.occupation = v; break; }

  if (/\bsc\b|dalit|दलित|अनुसूचित जाति|scheduled caste/.test(x)) out.category = 'sc';
  else if (/\bst\b|adivasi|आदिवासी|जनजाति|tribal/.test(x)) out.category = 'st';
  else if (/\bobc\b|पिछड़ा|backward/.test(x)) out.category = 'obc';
  else if (/general|सामान्य/.test(x)) out.category = 'general';

  let amount = null, m;
  if ((m = x.match(/([^\s]+)\s*(?:lakh|lac|लाख)/))) {
    const n = parseFloat(m[1]);
    amount = (isNaN(n) ? NUM[m[1]] : n) * 1e5;
  } else if ((m = x.match(/(\d+(?:\.\d+)?)\s*(?:hazar|hazaar|हजार|हज़ार|thousand|k\b)/))) amount = parseFloat(m[1]) * 1e3;
  else if ((m = x.match(/\d{4,}/))) amount = +m[0];
  if (amount) out.income = BANDS.find(b => amount <= b);

  const st = STATES.find(([v, en, hi]) => v !== 'other' && (x.includes(en.toLowerCase()) || x.includes(hi)));
  if (st) out.state = st[0];
  return out;
}

// Each condition in a scheme's rules is checked in turn; a condition passes only if the citizen's answer is known and satisfies it.
function match(rules, a) {
  const ok = (cond, key, test) => cond == null || (a[key] != null && test(a[key]));
  return ok(rules.maxIncome, 'income', v => v <= rules.maxIncome)
    && ok(rules.occupation, 'occupation', v => rules.occupation.includes(v))
    && ok(rules.gender, 'gender', v => v === rules.gender)
    && ok(rules.category, 'category', v => rules.category.includes(v))
    && ok(rules.states, 'state', v => rules.states.includes(v));
}
