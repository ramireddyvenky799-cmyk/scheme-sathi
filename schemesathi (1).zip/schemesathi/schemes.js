// Data: documents, 15 schemes (declarative rules), questionnaire, UI text. Bilingual: {en, hi}.
const DOCS = {
  aadhaar: { icon: '🪪', en: 'Aadhaar Card', hi: 'आधार कार्ड' },
  land: { icon: '📜', en: 'Land Record (Khasra/Khatauni)', hi: 'भूमि रिकॉर्ड (खसरा/खतौनी)' },
  income: { icon: '🧾', en: 'Income Certificate', hi: 'आय प्रमाण पत्र' },
  ration: { icon: '🍚', en: 'Ration Card', hi: 'राशन कार्ड' },
  bank: { icon: '🏦', en: 'Bank Passbook', hi: 'बैंक पासबुक' },
  pan: { icon: '💳', en: 'PAN Card', hi: 'पैन कार्ड' },
  caste: { icon: '📄', en: 'Caste Certificate', hi: 'जाति प्रमाण पत्र' },
  photo: { icon: '📷', en: 'Passport Photo', hi: 'पासपोर्ट फोटो' },
  business: { icon: '🏪', en: 'Business Proof / Plan', hi: 'व्यवसाय का प्रमाण / योजना' },
  marks: { icon: '🎓', en: 'Marksheet & Admission Proof', hi: 'मार्कशीट और प्रवेश प्रमाण' },
  birth: { icon: '👶', en: 'Girl Child Birth Certificate', hi: 'बच्ची का जन्म प्रमाण पत्र' },
  domicile: { icon: '🏠', en: 'Domicile / Residence Proof', hi: 'निवास प्रमाण पत्र' },
};

// rules: maxIncome (₹/yr), occupation[], gender, category[], states[] — omitted key = no condition.
const s = (id, nameEn, nameHi, benEn, benHi, rules, docs, howEn, howHi) =>
  ({ id, name: { en: nameEn, hi: nameHi }, benefit: { en: benEn, hi: benHi }, rules, docs, how: { en: howEn, hi: howHi } });

const SCHEMES = [
  s('pmkisan', 'PM-Kisan Samman Nidhi', 'पीएम-किसान सम्मान निधि', '₹6,000 per year in 3 instalments', '₹6,000 प्रति वर्ष, 3 किस्तों में',
    { occupation: ['farmer'], maxIncome: 500000 }, ['aadhaar', 'land', 'bank'], 'Register at pmkisan.gov.in or at your CSC.', 'pmkisan.gov.in पर या अपने CSC पर पंजीकरण करें।'),
  s('fasal', 'PM Fasal Bima Yojana', 'पीएम फसल बीमा योजना', 'Crop insurance against loss from drought, flood or pests', 'सूखा, बाढ़ या कीट से फसल नुकसान पर बीमा',
    { occupation: ['farmer'] }, ['aadhaar', 'land', 'bank'], 'Apply through your bank, CSC or pmfby.gov.in before the sowing deadline.', 'बुवाई की अंतिम तिथि से पहले बैंक, CSC या pmfby.gov.in से आवेदन करें।'),
  s('kcc', 'Kisan Credit Card', 'किसान क्रेडिट कार्ड', 'Low-interest farm loans for seeds, fertiliser and tools', 'बीज, खाद और औज़ार के लिए कम ब्याज पर कृषि ऋण',
    { occupation: ['farmer'] }, ['aadhaar', 'land', 'bank', 'photo'], 'Apply at your nearest bank branch or cooperative bank.', 'अपनी नज़दीकी बैंक शाखा या सहकारी बैंक में आवेदन करें।'),
  s('rythu', 'State Farmer Investment Support (Telangana, Andhra Pradesh)', 'राज्य किसान निवेश सहायता (तेलंगाना, आंध्र प्रदेश)', 'Yearly per-acre investment support (amount set by state)', 'प्रति एकड़ वार्षिक निवेश सहायता (राशि राज्य तय करता है)',
    { occupation: ['farmer'], states: ['telangana', 'andhra'] }, ['aadhaar', 'land', 'bank'], 'Contact your village agriculture officer.', 'अपने गाँव के कृषि अधिकारी से संपर्क करें।'),
  s('pmjay', 'Ayushman Bharat (PM-JAY)', 'आयुष्मान भारत (पीएम-जय)', 'Free hospital treatment up to ₹5 lakh per family per year', 'प्रति परिवार प्रति वर्ष ₹5 लाख तक मुफ़्त इलाज',
    { maxIncome: 250000 }, ['aadhaar', 'ration', 'income'], 'Check your name at mera.pmjay.gov.in, then get your card at a CSC or empanelled hospital.', 'mera.pmjay.gov.in पर नाम देखें, फिर CSC या सूचीबद्ध अस्पताल से कार्ड बनवाएँ।'),
  s('pmay', 'PM Awas Yojana (Gramin)', 'पीएम आवास योजना (ग्रामीण)', 'Financial aid to build a pucca house', 'पक्का घर बनाने के लिए आर्थिक सहायता',
    { maxIncome: 250000 }, ['aadhaar', 'income', 'bank', 'domicile'], 'Apply through your Gram Panchayat or at pmayg.nic.in.', 'अपनी ग्राम पंचायत से या pmayg.nic.in पर आवेदन करें।'),
  s('ujjwala', 'PM Ujjwala Yojana', 'पीएम उज्ज्वला योजना', 'Free LPG connection for women from poor households', 'गरीब परिवार की महिलाओं को मुफ़्त एलपीजी कनेक्शन',
    { gender: 'female', maxIncome: 100000 }, ['aadhaar', 'ration', 'bank'], 'Apply at your nearest LPG distributor or pmuy.gov.in.', 'नज़दीकी एलपीजी वितरक के पास या pmuy.gov.in पर आवेदन करें।'),
  s('ladli', 'Ladli Behna Yojana (Madhya Pradesh)', 'लाड़ली बहना योजना (मध्य प्रदेश)', '₹1,250 per month for eligible women', 'पात्र महिलाओं को ₹1,250 प्रति माह',
    { gender: 'female', maxIncome: 250000, states: ['mp'] }, ['aadhaar', 'bank', 'domicile', 'income'], 'Apply at your ward or Gram Panchayat camp.', 'अपने वार्ड या ग्राम पंचायत के शिविर में आवेदन करें।'),
  s('matru', 'PM Matru Vandana Yojana', 'पीएम मातृ वंदना योजना', '₹5,000 for pregnant and nursing mothers', 'गर्भवती और स्तनपान कराने वाली माताओं को ₹5,000',
    { gender: 'female' }, ['aadhaar', 'bank'], 'Register at your Anganwadi centre or ASHA worker.', 'अपने आंगनवाड़ी केंद्र या आशा कार्यकर्ता के पास पंजीकरण करें।'),
  s('sukanya', 'Sukanya Samriddhi Yojana', 'सुकन्या समृद्धि योजना', 'High-interest savings account for a girl child', 'बेटी के लिए ऊँची ब्याज दर वाला बचत खाता',
    { gender: 'female' }, ['aadhaar', 'birth', 'photo'], 'Open the account at any post office or bank with ₹250 minimum.', 'किसी भी डाकघर या बैंक में न्यूनतम ₹250 से खाता खोलें।'),
  s('mudra', 'PM Mudra Yojana', 'पीएम मुद्रा योजना', 'Collateral-free business loans up to ₹10 lakh', 'बिना गारंटी ₹10 लाख तक का व्यावसायिक ऋण',
    { occupation: ['entrepreneur'] }, ['aadhaar', 'pan', 'business', 'bank'], 'Apply at any bank or at udyamimitra.in.', 'किसी भी बैंक में या udyamimitra.in पर आवेदन करें।'),
  s('standup', 'Stand-Up India', 'स्टैंड-अप इंडिया', 'Loan of ₹10 lakh to ₹1 crore for women and SC/ST entrepreneurs', 'महिला और SC/ST उद्यमियों के लिए ₹10 लाख से ₹1 करोड़ का ऋण',
    { occupation: ['entrepreneur'], gender: 'female' }, ['aadhaar', 'pan', 'business', 'bank'], 'Apply at standupmitra.in or a scheduled commercial bank.', 'standupmitra.in पर या किसी अनुसूचित वाणिज्यिक बैंक में आवेदन करें।'),
  s('vishwa', 'PM Vishwakarma', 'पीएम विश्वकर्मा', 'Toolkit grant ₹15,000, skill training and low-interest loans for artisans', 'कारीगरों को ₹15,000 का टूलकिट, प्रशिक्षण और कम ब्याज ऋण',
    { occupation: ['labourer'] }, ['aadhaar', 'bank', 'photo'], 'Register at pmvishwakarma.gov.in or your CSC.', 'pmvishwakarma.gov.in पर या अपने CSC पर पंजीकरण करें।'),
  s('mgnrega', 'MGNREGA Job Card', 'मनरेगा जॉब कार्ड', 'Up to 100 days of guaranteed wage work per year', 'प्रति वर्ष 100 दिन तक की गारंटीशुदा मज़दूरी',
    { occupation: ['labourer', 'farmer'], maxIncome: 250000 }, ['aadhaar', 'bank', 'photo'], 'Apply for a job card at your Gram Panchayat.', 'जॉब कार्ड के लिए अपनी ग्राम पंचायत में आवेदन करें।'),
  s('scholar', 'Post-Matric Scholarship (SC/ST)', 'पोस्ट-मैट्रिक छात्रवृत्ति (SC/ST)', 'Tuition fee and maintenance allowance for students', 'छात्रों के लिए ट्यूशन फ़ीस और रख-रखाव भत्ता',
    { occupation: ['student'], category: ['sc', 'st'], maxIncome: 250000 }, ['aadhaar', 'caste', 'income', 'marks', 'bank'], 'Apply on scholarships.gov.in (National Scholarship Portal).', 'scholarships.gov.in (राष्ट्रीय छात्रवृत्ति पोर्टल) पर आवेदन करें।'),
];

const BANDS = [100000, 250000, 500000, 1e9];
const STATES = [
  ['andhra', 'Andhra Pradesh', 'आंध्र प्रदेश'], ['bihar', 'Bihar', 'बिहार'], ['gujarat', 'Gujarat', 'गुजरात'],
  ['karnataka', 'Karnataka', 'कर्नाटक'], ['mp', 'Madhya Pradesh', 'मध्य प्रदेश'], ['maharashtra', 'Maharashtra', 'महाराष्ट्र'],
  ['odisha', 'Odisha', 'ओडिशा'], ['rajasthan', 'Rajasthan', 'राजस्थान'], ['tn', 'Tamil Nadu', 'तमिल नाडु'],
  ['telangana', 'Telangana', 'तेलंगाना'], ['up', 'Uttar Pradesh', 'उत्तर प्रदेश'], ['wb', 'West Bengal', 'पश्चिम बंगाल'],
  ['other', 'Other state', 'अन्य राज्य'],
];

const o = (v, icon, en, hi) => ({ v, icon, en, hi });
const Q = [
  { key: 'category', title: { en: 'Which category are you from?', hi: 'आप किस वर्ग से हैं?' }, options: [
    o('general', '👤', 'General', 'सामान्य'), o('obc', '👥', 'OBC', 'अन्य पिछड़ा वर्ग'), o('sc', '🏘️', 'SC', 'अनुसूचित जाति'), o('st', '🌿', 'ST', 'अनुसूचित जनजाति')] },
  { key: 'income', title: { en: 'What is your family income per year?', hi: 'आपके परिवार की सालाना आय कितनी है?' }, options: [
    o(BANDS[0], '🪙', 'Below ₹1 lakh', '₹1 लाख से कम'), o(BANDS[1], '💰', '₹1–2.5 lakh', '₹1–2.5 लाख'),
    o(BANDS[2], '💵', '₹2.5–5 lakh', '₹2.5–5 लाख'), o(BANDS[3], '🏦', 'Above ₹5 lakh', '₹5 लाख से ज़्यादा')] },
  { key: 'occupation', title: { en: 'What work do you do?', hi: 'आप क्या काम करते हैं?' }, options: [
    o('farmer', '🌾', 'Farmer', 'किसान'), o('labourer', '🧱', 'Labourer / Artisan', 'मज़दूर / कारीगर'), o('entrepreneur', '🏪', 'Business owner', 'व्यापारी / उद्यमी'),
    o('student', '🎓', 'Student', 'छात्र'), o('homemaker', '🏠', 'Homemaker', 'गृहिणी'), o('other', '💼', 'Other', 'अन्य')] },
  { key: 'gender', title: { en: 'Are you a woman or a man?', hi: 'आप महिला हैं या पुरुष?' }, options: [
    o('female', '👩', 'Woman', 'महिला'), o('male', '👨', 'Man', 'पुरुष'), o('other', '🧑', 'Other', 'अन्य')] },
  { key: 'state', title: { en: 'Which state do you live in?', hi: 'आप किस राज्य में रहते हैं?' },
    options: STATES.map(([v, en, hi]) => o(v, '📍', en, hi)) },
];

const T = {
  en: {
    tagline: 'Find government schemes you can get — just speak.', mic: 'Tap and speak', micHint: 'Example: "I am a small farmer, my income is under 1 lakh"',
    typePh: 'Or type here…', heard: 'We understood:', showSchemes: 'Show schemes', startQ: 'Answer 5 questions', continueQ: 'Answer remaining questions',
    back: 'Back', skip: 'Skip', step: 'Question', listening: 'Listening…', noSR: 'Voice input is not supported in this browser. Use Chrome, or type below.',
    micErr: 'Could not hear you. Please try again.', noVoice: 'No Hindi voice on this phone. Please read the cards.', noTTS: 'Speech is not supported here. Please read the cards.',
    profile: 'Your details', found: n => `${n} scheme${n === 1 ? '' : 's'} for you`, none: 'No matching scheme found. Visit your nearest CSC for help.',
    listen: '🔊 Listen', stop: '⏹ Stop', docs: 'Documents needed', steps: 'How to apply', checklist: 'Your document checklist',
    print: '🖨 Print', download: '⬇ Download', whatsapp: 'WhatsApp', restart: 'Start over', note: 'Amounts and rules are indicative. Confirm at the official portal or your CSC.',
    s1: 'Keep these documents ready.', s3: 'Submit the form and keep the receipt number safe.', docsAre: 'Documents needed are',
  },
  hi: {
    tagline: 'सरकारी योजनाएँ जानने के लिए बस बोलिए।', mic: 'दबाइए और बोलिए', micHint: 'जैसे: "मैं छोटा किसान हूँ, मेरी आय 1 लाख से कम है"',
    typePh: 'या यहाँ लिखिए…', heard: 'हमने यह समझा:', showSchemes: 'योजनाएँ देखें', startQ: '5 सवालों के जवाब दें', continueQ: 'बाकी सवालों के जवाब दें',
    back: 'पीछे', skip: 'छोड़ें', step: 'सवाल', listening: 'सुन रहे हैं…', noSR: 'इस ब्राउज़र में बोलकर पूछना उपलब्ध नहीं है। Chrome इस्तेमाल करें या नीचे लिखें।',
    micErr: 'आवाज़ सुनाई नहीं दी। कृपया फिर कोशिश करें।', noVoice: 'इस फ़ोन में हिंदी आवाज़ नहीं है। कृपया कार्ड पढ़ें।', noTTS: 'यहाँ बोलकर सुनाना उपलब्ध नहीं है। कृपया कार्ड पढ़ें।',
    profile: 'आपकी जानकारी', found: n => `आपके लिए ${n} योजना${n === 1 ? '' : 'एँ'}`, none: 'कोई योजना नहीं मिली। मदद के लिए नज़दीकी CSC जाएँ।',
    listen: '🔊 सुनें', stop: '⏹ रोकें', docs: 'ज़रूरी दस्तावेज़', steps: 'आवेदन कैसे करें', checklist: 'आपके दस्तावेज़ों की सूची',
    print: '🖨 प्रिंट', download: '⬇ डाउनलोड', whatsapp: 'व्हाट्सऐप', restart: 'फिर से शुरू करें', note: 'राशि और नियम सांकेतिक हैं। आधिकारिक पोर्टल या CSC पर पुष्टि करें।',
    s1: 'ये दस्तावेज़ तैयार रखें।', s3: 'फ़ॉर्म जमा करें और रसीद नंबर संभालकर रखें।', docsAre: 'ज़रूरी दस्तावेज़ हैं',
  },
};
