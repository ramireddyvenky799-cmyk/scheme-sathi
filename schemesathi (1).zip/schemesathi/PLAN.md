# SchemeSathi – Frontend Plan

Scope: frontend only. Vanilla JS (ES6+), semantic HTML5, CSS Flexbox/Grid. No build step, no backend, no dependencies.
Run: open `index.html` in Chrome/Edge (voice recognition needs Chrome-based browsers; serve via `npx serve` or localhost if the mic is blocked on `file://`).

## Files
| File | Purpose |
|---|---|
| `index.html` | Three views: Home (mic), Quiz (5 questions), Results (schemes + checklist) |
| `style.css` | Dark, high-contrast, large touch targets, print styles |
| `schemes.js` | Data: 15 schemes as declarative JSON rules, document list, bilingual text |
| `engine.js` | Pure logic: spoken-query parser and rule-based eligibility engine |
| `app.js` | UI: voice input, quiz, TTS, checklist, language toggle |

## Must-have features -> implementation
1. **Regional voice query**: `SpeechRecognition` (`hi-IN`, or `en-IN` in English mode, auto-retry in English if Hindi is unsupported). Live transcript shown while speaking. Typed-query box as fallback when the browser has no speech recognition.
2. **5-question questionnaire**: Category -> Income -> Occupation -> Gender -> State. Large icon cards, progress bar, back/skip, question read aloud.
3. **Matching engine**: each scheme has `rules: {maxIncome, occupation[], gender, category[], states[]}`. Conditions are checked sequentially; a condition passes only when the citizen's answer is known and satisfies it.
4. **Spoken explainer**: per-scheme "Listen" button using `SpeechSynthesisUtterance` (benefit, documents, steps). Text card always visible; warning if no Hindi voice is installed.
5. **Document checklist**: union of documents across matched schemes, tickable, printable, downloadable `.txt`, and WhatsApp share (stretch feature, 5 lines).
6. **Bilingual + dark theme**: Hindi/English toggle (persisted), dark high-contrast theme, 18px+ base font.

## Voice -> profile flow
Transcript -> lowercase -> keyword/regex parser (Hindi script, Hinglish, English) -> sets Category / Income band / Occupation / Gender / State -> shown as **icon confirmation chips** so non-literate users can verify -> "Show schemes" or "Answer remaining questions".

Demo: "Main chhota kisan hoon, meri aay 1 lakh se kam hai" -> Farmer + Income below 1 lakh -> PM-Kisan, PM Fasal Bima, etc.

## Out of scope (stretch, not built)
CSC finder, form-filling simulator.

## Caveat
Benefit amounts and rules are simplified for demo use. Users should confirm on the official portal or at a CSC.
